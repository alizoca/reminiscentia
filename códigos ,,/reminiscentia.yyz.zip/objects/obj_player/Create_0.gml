// Evento Create de obj_player
move_speed = 4;
h_speed = 0;
v_speed = 0;