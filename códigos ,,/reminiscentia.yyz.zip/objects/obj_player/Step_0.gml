// Evento Step de obj_player

// 1. Capturar entradas do teclado (WASD ou Setas)
var key_right = keyboard_check(ord("D")) || keyboard_check(vk_right);
var key_left  = keyboard_check(ord("A")) || keyboard_check(vk_left);
var key_down  = keyboard_check(ord("S")) || keyboard_check(vk_down);
var key_up    = keyboard_check(ord("W")) || keyboard_check(vk_up);

// 2. Calcular a direção do movimento
var h_input = key_right - key_left;
var v_input = key_down - key_up;

h_speed = h_input * move_speed;
v_speed = v_input * move_speed;

// 3. Sistema de Colisão Horizontal
if (place_meeting(x + h_speed, y, obj_solid)) {
    while (!place_meeting(x + sign(h_speed), y, obj_solid)) {
        x += sign(h_speed);
    }
    h_speed = 0;
}
x += h_speed;

// 4. Sistema de Colisão Vertical
if (place_meeting(x, y + v_speed, obj_solid)) {
    while (!place_meeting(x, y + sign(v_speed), obj_solid)) {
        y += sign(v_speed);
    }
    v_speed = 0;
}
y += v_speed;